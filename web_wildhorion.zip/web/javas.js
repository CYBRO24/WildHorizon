index(window).scroll(function(){
    if (index(this).scrollTop() > 50) {
        index('box').slideDown('slow');
    } else {
        index('box').slideUp('slow');
    }
});

